# --- Import Required Libraries ---
import streamlit as st
import numpy as np
import pandas as pd
import joblib
import matplotlib.pyplot as plt
import pickle
import os


os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Load trained model and scaler
model = joblib.load("best_model.pkl")
scaler = joblib.load("scaler.pkl")

# Configure Streamlit page
st.set_page_config(page_title="Loan Approval Prediction", layout="centered")
st.markdown("<h1 style='text-align: center; color: #2E86C1;'>🏠 Loan Approval Prediction</h1>", unsafe_allow_html=True)

# Session storage for prediction history
if 'history' not in st.session_state:
    st.session_state.history = []

# ========== SIDEBAR: Prediction History ==========
st.sidebar.title("📁 Prediction History")

if st.session_state.history:
    df = pd.DataFrame([{**rec["inputs"], "Prediction": rec["prediction"]} for rec in st.session_state.history])

    with st.sidebar.expander("🔍 Filter History"):
        min_income = st.slider("Min Monthly Income", 0, 30000, 0, step=1000)
        credit_filter = st.selectbox("Credit Score Filter", ["All", "Good", "Bad"])

        filtered_df = df[df["Income"] >= min_income]
        if credit_filter != "All":
            filtered_df = filtered_df[filtered_df["Credit Score"] == credit_filter]

        st.sidebar.dataframe(filtered_df)

    selected_index = st.sidebar.selectbox(
        "Select a record to view details:",
        list(range(1, len(st.session_state.history) + 1)),
        format_func=lambda x: f"Record #{x}"
    )
    selected_record = st.session_state.history[selected_index - 1]

    st.sidebar.markdown("---")
    st.sidebar.write("**Inputs:**")
    for k, v in selected_record["inputs"].items():
        st.sidebar.write(f"- **{k}**: {v}")

    st.sidebar.markdown(f"🔍 **Prediction:** `{selected_record['prediction']}`")

    if st.sidebar.button("🗑️ Delete This Record"):
        st.session_state.history.pop(selected_index - 1)
        st.rerun()

    if st.sidebar.button("🧹 Clear All History"):
        st.session_state.history.clear()
        st.rerun()

    csv = df.to_csv(index=False).encode("utf-8")
    st.sidebar.download_button("📅 Download All as CSV", csv, "loan_predictions.csv", "text/csv")
    st.markdown("### 📈 Prediction History Overview")
    st.line_chart(df["Prediction"].apply(lambda x: 1 if "Approved" in x else 0))
else:
    st.sidebar.info("No predictions yet.")

# ========== MAIN UI ==========
st.markdown("<p style='text-align: center;'>Please enter the applicant details to estimate loan approval.</p>", unsafe_allow_html=True)
st.markdown("---")

# ===== Input Fields =====
col1, col2 = st.columns(2)
with col1:
    person_age = st.slider("Applicant Age", 18, 100, 30)
    person_income = st.number_input("Monthly Income ($)", min_value=0, value=5000, step=500)
    person_emp_exp = st.number_input("Employment Years", min_value=0, value=5)
    cred_hist_len = st.number_input("Credit History Length (Years)", min_value=0, value=5)
    previous_default = st.selectbox("Previous Default", ['Yes', 'No'])

with col2:
    loan_amnt = st.number_input("Requested Loan Amount ($)", min_value=0, value=10000, step=1000)
    loan_int_rate = st.number_input("Interest Rate (%)", min_value=0.0, value=12.0, step=0.1)
    loan_percent_income = st.slider("Loan as % of Income", 0.0, 1.0, 0.2)
    credit_score = st.number_input("Credit Score (390 - 850)", min_value=390, max_value=850, value=700, step=1)
    gender = st.selectbox("Gender", ['Male', 'Female'])

st.markdown("### 📚 Additional Details")
col3, col4 = st.columns(2)
with col3:
    education = st.selectbox("Education Level", ['Bachelor', 'Doctorate', 'High School', 'Master', 'Other'])

with col4:
    home_ownership = st.selectbox("Home Ownership", ['OTHER', 'OWN', 'RENT'])

loan_intent = st.selectbox("Loan Purpose", ['EDUCATION', 'HOMEIMPROVEMENT', 'MEDICAL', 'PERSONAL', 'VENTURE', 'Other'])

# ========== Predict Button ==========
st.markdown("---")
if st.button("🔍 Predict Loan Approval"):
    input_data = [
        person_age, person_income, person_emp_exp, loan_amnt, loan_int_rate,
        loan_percent_income, cred_hist_len,
        credit_score, int(gender == 'Male'),
        int(education == 'Bachelor'), int(education == 'Doctorate'),
        int(education == 'High School'), int(education == 'Master'),
        int(home_ownership == 'OTHER'), int(home_ownership == 'OWN'), int(home_ownership == 'RENT'),
        int(loan_intent == 'EDUCATION'), int(loan_intent == 'HOMEIMPROVEMENT'),
        int(loan_intent == 'MEDICAL'), int(loan_intent == 'PERSONAL'),
        int(loan_intent == 'VENTURE'),
        int(previous_default == 'Yes')
    ]

    input_scaled = scaler.transform([input_data])
    prediction = model.predict(input_scaled)

    result = "✅ Loan Approved" if prediction[0] == 1 else "❌ Loan Denied"
    if prediction[0] == 1:
        st.success("✅ **Loan Approved** — The applicant is likely to be eligible.")
    else:
        st.error("❌ **Loan Denied** — The applicant may not meet the eligibility criteria.")

    st.session_state.history.append({
        "inputs": {
            "Age": person_age,
            "Income": person_income,
            "Employment (Years)": person_emp_exp,
            "Loan Amount": loan_amnt,
            "Interest Rate": loan_int_rate,
            "Loan % Income": loan_percent_income,
            "Credit History (Years)": cred_hist_len,
            "Credit Score": credit_score,
            "Gender": gender,
            "Education": education,
            "Home Ownership": home_ownership,
            "Loan Purpose": loan_intent,
            "Previous Default": previous_default
        },
        "prediction": result
    })

    st.markdown("### 📊 Current Prediction Visualization")
    fig, ax = plt.subplots()
    ax.bar(["Loan Outcome"], [1 if prediction[0] == 1 else 0], color="#27AE60" if prediction[0] == 1 else "#C0392B")
    ax.set_ylabel("Approval (1) / Denial (0)")
    ax.set_ylim(0, 1.2)
    st.pyplot(fig)

    with open("loan_session_history.pkl", "wb") as f:
        pickle.dump(st.session_state.history, f)

# --- Upload CSV for Batch Prediction ---
model_columns = [
    'person_age', 'person_income', 'person_emp_exp', 'loan_amnt', 'loan_int_rate',
    'loan_percent_income', 'cb_person_cred_hist_length', 'credit_score',
    'person_gender_male',
    'person_education_Bachelor', 'person_education_Doctorate',
    'person_education_High School', 'person_education_Master',
    'person_home_ownership_OTHER', 'person_home_ownership_OWN',
    'person_home_ownership_RENT',
    'loan_intent_EDUCATION', 'loan_intent_HOMEIMPROVEMENT',
    'loan_intent_MEDICAL', 'loan_intent_PERSONAL', 'loan_intent_VENTURE',
    'previous_loan_defaults_on_file_Yes'
]

uploaded_file = st.file_uploader("📄 Upload CSV for Batch Prediction", type=["csv"])

if uploaded_file is not None:
    raw_data = pd.read_csv(uploaded_file)
    st.write("📄 Uploaded Data:")
    st.write(raw_data)

    csv = raw_data.to_csv(index=False).encode("utf-8")
    st.download_button("Download Results", csv, "predictions.csv", "text/csv")

# --- Download session ---
pkl = pickle.dumps(st.session_state.history)
st.download_button("📦 Download Session (.pkl)", pkl, "loan_session.pkl")

# --- About Section ---
with st.expander("ℹ️ About this project"):
    st.write("""
        This app predicts loan approval based on applicant financial and demographic details.

        **Models Tried:**
        - Logistic Regression
        - K-Nearest Neighbors
        - Support Vector Machine
        - Kernel SVM
        - Naive Bayes
        - Decision Tree
        - Random Forest

        ✅ The final deployed model is **Random Forest**, which showed the best classification accuracy.
    """)
